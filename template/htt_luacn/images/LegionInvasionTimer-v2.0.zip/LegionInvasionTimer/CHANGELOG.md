# LegionInvasionTimer

## [v2.0](https://github.com/funkydude/LegionInvasionTimer/tree/v2.0) (2016-08-23) [](#top)
[Full Changelog](https://github.com/funkydude/LegionInvasionTimer/compare/v1.7...v2.0)

-   Only stop the zone bars in the boss phase if the boss shows a bar.  
-   Fix boss bars being paused  
-   Fix bar stopping  
-   Upgrade to a proper bar handling system, thanks to contributions from developaws. Fixes bars overlapping and causing SetPoint errors on occasion.  
-   Update deDE (#29)  
-   Fix reloading during a boss breaking the timers.  
-   update README  
-   Update esES.lua (#30)  
