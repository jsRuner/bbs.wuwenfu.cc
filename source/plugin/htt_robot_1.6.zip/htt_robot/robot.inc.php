<?php
/**
 * Created by JetBrains PhpStorm.
 * User: ���ĸ� hi_php@163.com
 * Blog: wuwenfu.cn
 * Date: 2016/4/8
 * Time: 16:51
 * description:
 *
 *
 */
//http://bbs.wuwenfu.cc/plugin.php?id=htt_robot:robot ���ʸ�ҳ���url
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


// echo $_G['siteurl'];
// exit();

/*echo "<pre>";
var_dump($_G['setting']['discuzurl']);
echo "</pre>";

exit();*/
if ($_POST['formhash']!= FORMHASH) {
    showmessage('undefined_action');
}

function curl_html($url)
{

    $curl = curl_init(); //����curl
    curl_setopt($curl, CURLOPT_URL, $url); //���������ַ
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);  //�Ƿ���� 1 or true �ǲ���� 0  or false���
    $html = curl_exec($curl); //ִ��curl����
    curl_close($curl);

    return $html;
}

global $_G;

loadcache('plugin');
$var = $_G['cache']['plugin'];
$groupstr = $var['htt_robot']['groups']; //�û��顣��Щ�û�����Կ��������ˡ�
$welcome_msg = $var['htt_robot']['welcome_msg']; //��ӭ��
$tuling_key = $var['htt_robot']['tuling_key']; //key
$check = $var['htt_robot']['is_show'];  //1���� 2����


$key = $tuling_key;

$info = $_POST['msg'];

$url = 'http://www.tuling123.com/openapi/api?key=' . $key . '&info=' . urlencode($info);

$replystr = dfsockopen($url);

$replyarr = json_decode($replystr, true);

$returnmsg = $replyarr['text'];

//����Զ�����������Ч����ʹ��curlģ��
if (empty($returnmsg)) {
    $replystr = curl_html($url);
    $replyarr = json_decode($replystr, true);
    $returnmsg = $replyarr['text'];
}

//��������У���ʹ��file_get_contents
if (empty($returnmsg)) {
    $replystr = file_get_contents($url);
    $replyarr = json_decode($replystr, true);
    $returnmsg = $replyarr['text'];
}

echo json_encode(array('msg' =>$returnmsg));

if($_G['charset'] == 'gbk'){

    $info =   iconv("utf-8", "gbk",$info);
    $returnmsg =   iconv("utf-8", "gbk",$returnmsg);

}


if(empty($_G['username'])){
    $username=lang('plugin/htt_robot', 'guest') ;
}else{
    $username = $_G['username'];
}

$insert_array = array(
    'uid'=>$_G['uid'],
    'username'=>$username,
    'ip'=> $_G['clientip'],
    'dateline'=>TIMESTAMP,
    'message'=>$info,
    'reply'=>$returnmsg,
);



//�浽��¼��ȥ��
DB::insert("httrobot_message",$insert_array);

// echo json_encode(array('msg' => $replyarr['text']));

