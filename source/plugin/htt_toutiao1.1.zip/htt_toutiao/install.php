<?php
/**
 * Created by JetBrains PhpStorm.
 * User: 吴文付 hi_php@163.com
 * Blog: wuwenfu.cn
 * Date: 2016/4/3
 * Time: 16:55
 * description:
 *
 *
 */


if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

//todo:后期添加表
$finish = True;
