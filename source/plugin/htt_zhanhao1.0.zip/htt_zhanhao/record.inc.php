<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: admincp.inc.php 29364 2012-04-09 02:51:41Z monkey $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$Plang = $scriptlang['htt_zhanhao'];



if($_GET['op'] == 'add') {

} elseif($_GET['op'] == 'delete') {
    C::t('#htt_zhanhao#record')->delete_by_id($_GET['id']);
    ajaxshowheader();
    echo $Plang['show_action_succeed'];
    ajaxshowfooter();
}

$ppp = 100;
$resultempty = FALSE;
$srchadd = $searchtext = $extra = $srchid = '';
$page = max(1, intval($_GET['page']));

//������׷�Ӳ������û�  ����  ״̬��
if(!empty($_GET['username'])){
    $srchadd .= "AND username='".$_GET['username']."'";
    $extra .= '&username='.$_GET['username'];
}



if($searchtext) {
    $searchtext = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=htt_zhanhao&pmod=record">'.$Plang['search'].'</a>&nbsp'.$searchtext;
}

loadcache('usergroups');

showtableheader();
showformheader('plugins&operation=config&do='.$pluginid.'&identifier=htt_zhanhao&pmod=record', 'repeatsubmit');
showsubmit('repeatsubmit', $Plang['search'], $lang['username'].': <input name="username" value="'.htmlspecialchars($_GET['username']).'" class="txt" />&nbsp;&nbsp;', $searchtext);
showformfooter();



echo '<tr class="header"><th></th><th>'.$Plang['username'].'</th><th>'.$lang['ip'].'</th><th>'.$Plang['dateline'].'</th><th>'.$Plang['zhanhao'].'</th><th>'.$Plang['password'].'</th><th></th></tr>';

if(!$resultempty) {

    $count = C::t('#htt_zhanhao#record')->count_by_search($srchadd);
    $records = C::t('#htt_zhanhao#record')->fetch_all_by_search($srchadd, ($page - 1) * $ppp, $ppp);

    $zhanhaos = C::t('#htt_zhanhao#zhanhao')->fetch_all();

    $i = 0;
    foreach($records as $record) {



        $i++;
        echo '<tr>
<td>'.$record['username'].'</td>'.
            '<td>'.$record['ip'].'</td>'.
            '<td>'.date('Y-m-d H:i:s',$record['dateline']).'</td>'.
            '<td>'.$zhanhaos[$record['zid']]['username'].'</td>'.
            '<td>'.$zhanhaos[$record['zid']]['password'].'</td>'.
            '<td><a id="p'.$i.'" onclick="ajaxget(this.href, this.id, \'\');return false" href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=htt_zhanhao&pmod=record&id='.$record['id'].'&op=delete">['.$lang['delete'].']</a></td>
            </tr>';
    }
}
showtablefooter();

echo multi($count, $ppp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=htt_zhanhao&pmod=record$extra");

?>