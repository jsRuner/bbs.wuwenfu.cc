<?php


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include template('htt_qqlogin:more');
?>