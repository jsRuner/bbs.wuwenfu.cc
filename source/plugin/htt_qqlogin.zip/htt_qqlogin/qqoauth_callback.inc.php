<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}





function get_avatar($uid, $size = 'middle', $type = '') {
    $size = in_array($size, array('big', 'middle', 'small')) ? $size : 'middle';
    $uid = abs(intval($uid));
    $uid = sprintf("%09d", $uid);
    $dir1 = substr($uid, 0, 3);
    $dir2 = substr($uid, 3, 2);
    $dir3 = substr($uid, 5, 2);
    $typeadd = $type == 'real' ? '_real' : '';
    return $dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).$typeadd."_avatar_$size.jpg";
}

function set_home($uid, $dir = '.') {
    $uid = sprintf("%09d", $uid);
    $dir1 = substr($uid, 0, 3);
    $dir2 = substr($uid, 3, 2);
    $dir3 = substr($uid, 5, 2);
    echo $dir.'/'.$dir1.'/'.$dir2;
    !is_dir($dir.'/'.$dir1) && mkdir($dir.'/'.$dir1, 0777);
    !is_dir($dir.'/'.$dir1.'/'.$dir2) && mkdir($dir.'/'.$dir1.'/'.$dir2, 0777);
    !is_dir($dir.'/'.$dir1.'/'.$dir2.'/'.$dir3) && mkdir($dir.'/'.$dir1.'/'.$dir2.'/'.$dir3, 0777);
}



global $_G;
require libfile('function/member');
require_once libfile('function/misc');
require_once libfile('function/profile');

if($_G['setting']['bbclosed']) {
    if(($_GET['action'] != 'activation' && !$_GET['activationauth']) || !$_G['setting']['closedallowactivation'] ) {
        showmessage('register_disable', NULL, array(), array('login' => 1));
    }
}
loadcache(array('modreasons', 'stamptypeid', 'fields_required', 'fields_optional', 'fields_register', 'ipctrl'));



require_once("source/plugin/htt_qqlogin/API/qqConnectAPI.php");


if(!function_exists('sendmail')) {
    include libfile('function/mail');
}

require libfile('class/member');
loaducenter();


$qc = new QC();
$access_token = $qc->qq_callback();
$openid = $qc->get_openid();
//$openid = "123456789";

//$qc = new QC($access_token,$openid);
//$ret = $qc->get_user_info();



$query = DB::query("SELECT * FROM  ".DB::table("httqqlogin")." WHERE  `openid`= '$openid'");
$qqinfo = array();
if($item = DB::fetch($query)) {
    $qqinfo = $item;
    $members = C::t('common_member')->fetch_all_username_by_uid($qqinfo['uid']);
    $username = $members[$qqinfo['uid']];
    $members = C::t('common_member')->fetch_by_username($username);
    $uid = $qqinfo['uid'];
    $password = 'mimashi123456';
//��¼�߼���
    $_G['member'] = array(
        'username'=>$username,
        'uid'=>$uid,
    );
    $_G['group'] = C::t('common_usergroup')->fetch_all('10')[10];

    $result = userlogin($username, $password, $_GET['questionid'], $_GET['answer'], 'username', $_G['clientip']);

//��¼״̬��
    setloginstatus($result['member'], 2592000);

    $referer = dreferer();
    $ucsynlogin = $setting['allowsynlogin'] ? uc_user_synlogin($_G['uid']) : '';
    $param = array('username' => $_G['member']['username'], 'usergroup' => $_G['group']['grouptitle'], 'uid' => $_G['member']['uid']);
    showmessage('login_succeed', $referer ? $referer : './', $param, array('showdialog' => 1, 'locationtime' => true, 'extrajs' => $ucsynlogin));
    exit();
}


//�Ȳ���ucenter_members����
$username = 'qq'.time();
$password = 'mimashi123456';
$email = time().'@qq.com';
$questionid = '';
$answer = '';


$uid = uc_user_register(addslashes($username), $password, $email, $questionid, $answer, $_G['clientip']);
$_G['uid'] = $uid;



$insert_array = array(
    'uid'=>$uid,
    'password'=>$password,
    'openid'=>$openid,
    'access_token'=>$access_token,
    'dateline'=>TIMESTAMP,
);
DB::insert("httqqlogin",$insert_array);
C::t('common_member')->insert($uid, $username, md5(random(10)), $email, $_G['clientip'], 10);


/*//�����Ϊ��
$figureurl_1 =$ret['figureurl_1'];
if(!empty($figureurl_1)){
    set_home($uid,'uc_server/data/avatar');
    $smallavatarfile = 'uc_server/data/avatar'.get_avatar($uid, 'small');

    $avatarfile = file_get_contents($ret['figureurl_1']); //40*40
    file_put_contents($smallavatarfile,$avatarfile);
    DB::query("UPDATE ".DB::table("common_member")." SET avatarstatus=1 WHERE uid = $uid");
}*/


C::t('common_member_status')->update($_G['uid'], array('lastip' => $_G['clientip'], 'port' => $_G['remoteport'], 'lastvisit' =>TIMESTAMP, 'lastactivity' => TIMESTAMP));


//�û�������������
C::t('common_member_newprompt')->insert(
    array(
        'uid'=>$uid,
        'data'=>serialize(array('system'=>1))
    )
);



//����ͳ��
include_once libfile('function/stat');
updatestat('register');

$setting = $_G['setting'];
$welcomemsg = & $setting['welcomemsg'];
$welcomemsgtitle = & $setting['welcomemsgtitle'];
$welcomemsgtxt = & $setting['welcomemsgtxt'];

if($welcomemsg && !empty($welcomemsgtxt)) {
    $welcomemsgtitle = replacesitevar($welcomemsgtitle);
    $welcomemsgtxt = replacesitevar($welcomemsgtxt);
    if($welcomemsg == 1) {
        $welcomemsgtxt = nl2br(str_replace(':', '&#58;', $welcomemsgtxt));
        notification_add($uid, 'system', $welcomemsgtxt, array('from_id' => 0, 'from_idtype' => 'welcomemsg'), 1);
    } elseif($welcomemsg == 2) {
        sendmail_cron($email, $welcomemsgtitle, $welcomemsgtxt);
    } elseif($welcomemsg == 3) {
        sendmail_cron($email, $welcomemsgtitle, $welcomemsgtxt);
        $welcomemsgtxt = nl2br(str_replace(':', '&#58;', $welcomemsgtxt));
        notification_add($uid, 'system', $welcomemsgtxt, array('from_id' => 0, 'from_idtype' => 'welcomemsg'), 1);
    }
}



//��¼�߼���
$_G['member'] = array(
    'username'=>$username,
    'uid'=>$uid,
);


$_G['group'] = C::t('common_usergroup')->fetch_all('10')[10];

$result = userlogin($username, $password, $_GET['questionid'], $_GET['answer'], 'username', $_G['clientip']);

//��¼״̬��
setloginstatus($result['member'], 2592000);

$referer = dreferer();
$ucsynlogin = $setting['allowsynlogin'] ? uc_user_synlogin($_G['uid']) : '';
$param = array('username' => $_G['member']['username'], 'usergroup' => $_G['group']['grouptitle'], 'uid' => $_G['member']['uid']);
showmessage('login_succeed', $referer ? $referer : './', $param, array('showdialog' => 1, 'locationtime' => true, 'extrajs' => $ucsynlogin));







